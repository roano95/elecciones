/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mx.opin.sadimiapp.model;



/**
 *
 * @author jgali
 */
public class Calificaciones  {

    private Integer idCalificacion;

    private Integer idAlumno;

    private Integer calificacion;

    private Integer idMateriaSemestreCali;

    private Integer idUnidad;

    public Integer getIdCalificacion() {
        return idCalificacion;
    }

    public void setIdCalificacion(Integer idCalificacion) {
        this.idCalificacion = idCalificacion;
    }

    public Integer getIdAlumno() {
        return idAlumno;
    }

    public void setIdAlumno(Integer idAlumno) {
        this.idAlumno = idAlumno;
    }

    public Integer getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(Integer calificacion) {
        this.calificacion = calificacion;
    }

    public Integer getIdMateriaSemestreCali() {
        return idMateriaSemestreCali;
    }

    public void setIdMateriaSemestreCali(Integer idMateriaSemestreCali) {
        this.idMateriaSemestreCali = idMateriaSemestreCali;
    }

    public Integer getIdUnidad() {
        return idUnidad;
    }

    public void setIdUnidad(Integer idUnidad) {
        this.idUnidad = idUnidad;
    }


}
